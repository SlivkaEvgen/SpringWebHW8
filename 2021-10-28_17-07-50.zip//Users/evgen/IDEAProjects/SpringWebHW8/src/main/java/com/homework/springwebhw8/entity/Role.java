package com.homework.springwebhw8.entity;

import lombok.*;

import javax.persistence.*;
import java.util.Set;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(exclude = "users")
@ToString(exclude = "users")
@Entity
@Table(name = "role")
public class Role implements EntityModel<Long> {

    private static final long serialVersionUID = 726553041080466924L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", unique = true, length = 15)
    private Long id;

    //1. Admin - имеет возможность выполнять все операции CRUD.
    //2. Пользователь - имеет доступ только для чтения.
    @Column(name = "name", length = 15)
    private String name;

    @OneToMany( cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private Set<User> users;
}
