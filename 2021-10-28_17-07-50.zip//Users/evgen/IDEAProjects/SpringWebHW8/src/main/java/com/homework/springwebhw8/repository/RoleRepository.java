package com.homework.springwebhw8.repository;

import com.homework.springwebhw8.entity.Role;

public interface RoleRepository extends CrudRepositoryJDBC<Role,Long>{

}
