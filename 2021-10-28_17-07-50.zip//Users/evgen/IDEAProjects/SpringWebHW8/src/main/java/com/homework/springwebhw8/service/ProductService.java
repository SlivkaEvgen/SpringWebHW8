package com.homework.springwebhw8.service;

import com.homework.springwebhw8.entity.Product;
import com.homework.springwebhw8.repository.CrudRepositoryJDBC;
import org.springframework.stereotype.Service;

@Service
public class ProductService extends BaseService<Product, Long> {

    public ProductService(CrudRepositoryJDBC<Product, Long> repository) {
        super(repository);
    }

}
