package com.homework.springwebhw8.entity;

import lombok.*;
import javax.persistence.*;
import java.util.Set;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
//@EqualsAndHashCode(exclude = "products")
@ToString(exclude = "products")
@Entity
@Table(name = "manufacturer")
public class Manufacturer implements EntityModel<Long>{

    private static final long serialVersionUID = -3642932583756105991L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", unique = true, nullable = false, length = 15)
    private Long id;

    @Column(name = "name", nullable = false, length = 15)
    private String name;

    @OneToMany( cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private Set<Product> products;
}
