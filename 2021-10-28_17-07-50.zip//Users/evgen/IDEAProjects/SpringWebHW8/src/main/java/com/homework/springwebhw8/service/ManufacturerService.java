package com.homework.springwebhw8.service;

import com.homework.springwebhw8.entity.Manufacturer;
import com.homework.springwebhw8.repository.CrudRepositoryJDBC;
import org.springframework.stereotype.Service;

@Service
public class ManufacturerService extends BaseService<Manufacturer, Long> {

    public ManufacturerService(CrudRepositoryJDBC<Manufacturer, Long> repository) {
        super(repository);
    }

}
