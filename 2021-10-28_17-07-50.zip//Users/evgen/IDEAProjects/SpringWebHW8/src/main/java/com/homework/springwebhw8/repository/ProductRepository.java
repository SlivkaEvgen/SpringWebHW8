package com.homework.springwebhw8.repository;

import com.homework.springwebhw8.entity.Product;

public interface ProductRepository extends CrudRepositoryJDBC<Product,Long> {

}
