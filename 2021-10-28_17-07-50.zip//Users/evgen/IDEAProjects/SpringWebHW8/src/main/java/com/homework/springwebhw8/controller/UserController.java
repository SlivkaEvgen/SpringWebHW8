package com.homework.springwebhw8.controller;//package org.slivka.WebMarket.controller;

import com.homework.springwebhw8.entity.Role;
import com.homework.springwebhw8.entity.User;
import com.homework.springwebhw8.service.BaseService;
import io.swagger.annotations.ApiParam;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
@RestController
@RequestMapping(value = "user")
public class UserController {

    @Autowired
    private final BaseService<User,Long> baseService;

    @GetMapping
    public List<User> findAll() {
        return baseService.findAll();
    }

    @GetMapping({"/{id}", "/"})
    public Optional<User> findById(@PathVariable(required = false, name = "id") Optional<Long> id) {
        if (id.isPresent()) {
            return baseService.findById(id.get());
        }else return baseService.findById(1L);
    }

    @Operation(
            description = " Body of new User")
    @ApiResponses
    @PostMapping
    public User addNew(@RequestBody User user) {
        return baseService.addNew(user);
    }

    @DeleteMapping("{id}")
    public void deleteById(@PathVariable(name = "id") Long id) {
        baseService.deleteById(id);
    }

    @PutMapping("firstName")
    public User changeFirstName(@RequestParam(name = "ID", defaultValue = "1") Long id,
                              @ApiParam(required = true, name = "firstName", defaultValue = "Kevin")
                              @RequestParam(name = "First Name of User") String firstName) {
        return baseService.findById(id)
                .map(user -> {
                    user.setFirstName(firstName);
                    return baseService.addNew(user);
                })
                .orElse(null);
    }

    @PutMapping("lastName")
    public User changeLastName(@RequestParam(name = "ID", required = false, defaultValue = "1") Long id,
                              @ApiParam(required = true, name = "lastName", defaultValue = "Swinger")
                           @RequestParam(name = "Last Name of User") String lastName) {
        return baseService.findById(id)
                .map(user -> {
                    user.setLastName(lastName);
                    return baseService.addNew(user);
                })
                .orElse(null);
    }

    @PutMapping("gender")
    public User changePrice(
            @RequestParam(name = "id", required = false, defaultValue = "1") Long id,
            @RequestParam(name = "gender") String gender) {
        return baseService.findById(id)
                .map(user -> {
                    user.setGender(gender);
                    return baseService.addNew(user);
                })
                .orElse(null);
    }

    @PutMapping("role")
    public User changeManufacturer(
            @RequestParam(name = "id", required = false, defaultValue = "1") Long id,
            @RequestParam(name = "role") Role role) {
        return baseService.findById(id)
                .map(user -> {
                    user.setRole(role);
                    return baseService.addNew(user);
                })
                .orElse(null);
    }
//
//    public List<User> search(String keyword) {
//        return repository.search(keyword);
//    }
//
//    @RequestMapping("search")
//    public ModelAndView search(@RequestParam String keyword) {
//        List<User> result = repository.search(keyword);
//        ModelAndView mav = new ModelAndView("search");
//        mav.addObject("result", result);
//
//        return mav;
//    }
}
