package com.homework.springwebhw8.repository;

import com.homework.springwebhw8.entity.EntityModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

@NoRepositoryBean
public interface CrudRepositoryJDBC<T extends EntityModel<ID>, ID> extends JpaRepository<T, ID> {

//    @Query(value = "SELECT c FROM user c WHERE c.name LIKE '%' || :keyword || '%'"
//            + " OR c.email LIKE '%' || :keyword || '%'"
//            + " OR c.first_name LIKE '%' || :keyword || '%'")
//    List<User> search(@Param("keyword") String keyword);
//
//    @Query("select c from #{#entityName} c where c.name=?1")
//    List<T> findByName(String name);
}
