package com.homework.springwebhw8.repository;

import com.homework.springwebhw8.entity.User;

public interface UserRepository extends CrudRepositoryJDBC<User,Long>{

}
