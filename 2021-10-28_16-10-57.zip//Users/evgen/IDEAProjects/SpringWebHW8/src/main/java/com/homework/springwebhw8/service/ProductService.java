package com.homework.springwebhw8.service;

import com.homework.springwebhw8.entity.Product;
import com.homework.springwebhw8.repository.CrudRepositoryJDBC;
import org.springframework.stereotype.Service;

//@RequiredArgsConstructor // будет добавлен конструктор для всех полей final
@Service
public class ProductService extends BaseService<Product, Long> {

//    private final ProductRepository productRepository;

    public ProductService(CrudRepositoryJDBC<Product, Long> repository) {//@Qualifier("productRepository")
        super(repository);
//        this.productRepository = productRepository;
    }

//    @PostConstruct
//    public void getAll() {
//        List<Product> productList = productRepository.findAll();
//        System.out.println("******************************************************************");
//        System.out.println("ProductList = " + productList);
//    }

}
