package com.homework.springwebhw8.service;

import com.homework.springwebhw8.entity.Role;
import com.homework.springwebhw8.repository.CrudRepositoryJDBC;
import org.springframework.stereotype.Service;

@Service
public class RoleService extends BaseService<Role, Long>{


    public RoleService(CrudRepositoryJDBC<Role, Long> repository) {
        super(repository);
    }
}
