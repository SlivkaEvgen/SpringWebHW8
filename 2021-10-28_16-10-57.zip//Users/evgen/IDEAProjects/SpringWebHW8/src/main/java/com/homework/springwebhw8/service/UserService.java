package com.homework.springwebhw8.service;

import com.homework.springwebhw8.entity.User;
import com.homework.springwebhw8.repository.CrudRepositoryJDBC;
import org.springframework.stereotype.Service;

//@RequiredArgsConstructor // будет добавлен конструктор для всех полей final
@Service
public class UserService extends BaseService<User, Long> {

//    private final UserRepository userRepository;

    public UserService(CrudRepositoryJDBC<User, Long> repository) {
        super(repository);
//        this.userRepository = userRepository;
    }

//    @PostConstruct
//    public void getAll() {
//        List<User> userList = userRepository.findAll();
//        System.out.println("******************************************************************");
//        System.out.println("UserList = " + userList);
//    }

}
