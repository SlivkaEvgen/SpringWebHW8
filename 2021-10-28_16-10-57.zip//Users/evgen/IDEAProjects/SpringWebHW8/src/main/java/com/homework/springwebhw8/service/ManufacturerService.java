package com.homework.springwebhw8.service;

import com.homework.springwebhw8.entity.Manufacturer;
import com.homework.springwebhw8.repository.CrudRepositoryJDBC;
import org.springframework.stereotype.Service;

//@RequiredArgsConstructor // будет добавлен конструктор для всех полей final
@Service
public class ManufacturerService extends BaseService<Manufacturer, Long> {

//    private final ManufacturerRepository manufacturerRepository;

    public ManufacturerService(CrudRepositoryJDBC<Manufacturer, Long> repository) {
        super(repository);
//        this.manufacturerRepository = manufacturerRepository;
    }

//    @PostConstruct
//    public void getAll() {
//        List<Manufacturer> manufacturerList = manufacturerRepository.findAll();
//        System.out.println("******************************************************************");
//        System.out.println("ManufacturerList = " + manufacturerList);
//    }
}
