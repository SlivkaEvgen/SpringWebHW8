package com.homework.springwebhw8.controller;//package org.slivka.WebMarket.controller;

import com.homework.springwebhw8.entity.Manufacturer;
import com.homework.springwebhw8.service.BaseService;
import io.swagger.annotations.ApiParam;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RequiredArgsConstructor
@RestController
@RequestMapping(value = "manufacturer")
public class ManufacturerController {

    private final BaseService<Manufacturer,Long> baseService;

    @GetMapping
//    @RequestMapping(value = { "/manufacturer" }, method = RequestMethod.GET)
    public List<Manufacturer> findAll(Model model) {
        model.addAttribute("manufacturer", baseService.findAll());
        return baseService.findAll();
    }

    @GetMapping({"/{id}", "/"})
    public Optional<Manufacturer> findById(@PathVariable(required = false, name = "id") Optional<Long> id) {
        if (id.isPresent()) {
            return baseService.findById(id.get());
        }else return baseService.findById(1L);
    }

    @Operation(
            description = "...")
    @ApiResponses
    @PostMapping
    public Manufacturer save(@RequestBody Manufacturer manufacturer) {
        return baseService.addNew(manufacturer);
    }

    @DeleteMapping("{id}")
//    @RequestMapping("/delete/*")
    public void deleteById(@PathVariable(name = "id") Long id) {
        baseService.deleteById(id);
    }

    @PutMapping("name")
    public Manufacturer changeName(@RequestParam(name = "id", required = false, defaultValue = "1") Long id,
                              @ApiParam(required = true, name = "Name of Manufacturer", defaultValue = "Apple")
                              @RequestParam(name = "name") String name) {
        return baseService.findById(id)
                .map(manufacturer -> {
                    manufacturer.setName(name);
                    return baseService.addNew(manufacturer);
                })
                .orElse(null);
    }
}
