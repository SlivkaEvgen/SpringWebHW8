package com.homework.springwebhw8.service;

import com.homework.springwebhw8.entity.EntityModel;
import com.homework.springwebhw8.repository.CrudRepositoryJDBC;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

//@AllArgsConstructor
@RequiredArgsConstructor
@Service
public abstract class BaseService<T extends EntityModel<ID>, ID> {

    private final CrudRepositoryJDBC<T, ID> repository;

//    public BaseService(CrudRepositoryJDBC<T, ID> repository) {
//        this.repository = repository;
//    }

    public void deleteById(ID id) {
        repository.deleteById(id);
    }

    public List<T> findAll() {
        return repository.findAll();
    }

    public Optional<T> findById(ID id) {
        return repository.findById(id);
    }

    public T addNew(T t) {
        return repository.save(t);
    }
}
