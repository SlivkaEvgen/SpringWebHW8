package com.homework.springwebhw8.repository;


import com.homework.springwebhw8.entity.Manufacturer;

public interface ManufacturerRepository extends CrudRepositoryJDBC<Manufacturer,Long>{

}
